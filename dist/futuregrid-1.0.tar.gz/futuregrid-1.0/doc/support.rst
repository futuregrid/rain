.. _support:

Support
=======

If you run into problems when using FutureGrid Rain and Image Management, please use our 
help form at `https://portal.futuregrid.org/help <https://portal.futuregrid.org/help>`_