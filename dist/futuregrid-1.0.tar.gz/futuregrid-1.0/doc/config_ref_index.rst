.. _chap_config_ref:

Configuration file reference
============================

.. toctree::
   :maxdepth: 2
   
   config_ref_server.rst
   config_ref_client.rst
   config_ref_restrepo.rst