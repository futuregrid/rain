import unittest

class TestUsage(unittest.TestCase):
    def test_usage(self):
        # self.assertEqual(expected, usage())
        assert False # TODO: implement your test here

class TestMain(unittest.TestCase):
    def test_main(self):
        # self.assertEqual(expected, main())
        assert False # TODO: implement your test here

if __name__ == '__main__':
    unittest.main()
