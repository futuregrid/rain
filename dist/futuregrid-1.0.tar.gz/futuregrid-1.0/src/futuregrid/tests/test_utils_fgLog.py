import unittest

class TestGetLogFile(unittest.TestCase):
    def test_get_log_file(self):
        # self.assertEqual(expected, getLogFile(self))
        assert False # TODO: implement your test here

class TestDebug(unittest.TestCase):
    def test_debug(self):
        # self.assertEqual(expected, debug(self, text))
        assert False # TODO: implement your test here

class TestInfo(unittest.TestCase):
    def test_info(self):
        # self.assertEqual(expected, info(self, text))
        assert False # TODO: implement your test here

class TestWarning(unittest.TestCase):
    def test_warning(self):
        # self.assertEqual(expected, warning(self, text))
        assert False # TODO: implement your test here

class TestError(unittest.TestCase):
    def test_error(self):
        # self.assertEqual(expected, error(self, text))
        assert False # TODO: implement your test here

class TestClear(unittest.TestCase):
    def test_clear(self):
        # self.assertEqual(expected, clear(self))
        assert False # TODO: implement your test here

if __name__ == '__main__':
    unittest.main()
